package com.examen.examen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenPrograApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenPrograApplication.class, args);
	}

}
